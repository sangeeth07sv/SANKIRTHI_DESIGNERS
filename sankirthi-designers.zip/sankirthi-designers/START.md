# ▶ HOW TO RUN — SANKIRTHI DESIGNERS

## OPTION A — Run on Your Computer (Windows / Mac / Linux)

### Step 1: Install Node.js (one time only)
Download from: https://nodejs.org → Click "LTS" version → Install

### Step 2: Extract the zip
Extract `sankirthi-designers.zip` anywhere on your computer

### Step 3: Create your Firebase config file
Inside the `sankirthi-designers` folder, create a new file named exactly:
`.env.local`

Paste this inside it (replace with YOUR Firebase values):
```
NEXT_PUBLIC_FIREBASE_API_KEY=AIzaSy...
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=your-project.firebaseapp.com
NEXT_PUBLIC_FIREBASE_PROJECT_ID=your-project-id
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=your-project.appspot.com
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=123456789
NEXT_PUBLIC_FIREBASE_APP_ID=1:123:web:abc
```

### Step 4: Open terminal/command prompt in that folder
- Windows: Shift + Right-click the folder → "Open PowerShell here"
- Mac: Right-click → "New Terminal at Folder"

### Step 5: Run these 2 commands
```bash
npm install
npm run dev
```

### Step 6: Open browser
Go to: http://localhost:3000

Login with the email/password you created in Firebase Auth ✅

---

## OPTION B — Run on Vercel (No computer needed, from phone!)

1. Push this code to GitHub (upload files to your repo)
2. Go to vercel.com → Import the GitHub repo
3. Add the 6 Firebase env variables in Vercel settings
4. Click Deploy → Live in 2 minutes!

---

## Where to get Firebase values?
1. Go to console.firebase.google.com
2. Click your project → ⚙️ Settings → General
3. Scroll to "Your apps" → Click your web app
4. Copy the firebaseConfig values

